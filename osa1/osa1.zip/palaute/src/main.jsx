import ReactDOM from 'react-dom/client'
import App from './App1-10'

ReactDOM.createRoot(document.getElementById('root')).render(<App />)